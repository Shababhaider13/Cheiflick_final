
      	<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
        <img src="images/pizza-round.png" class="" alt="" width="70px;" height="75px;"/> 
        <h3 style="display:inline; Padding-left:20px; font-family:Metropolis,Regular;font-weight:300">Pizza Veloper</h3>
          <p class="col-2 text-muted" style="float:right; font-size:18px;"><del class="text-12">Rs 250</del><span
                      class="text-second font-weight-bold"> Rs 150</span>
                      
                      
        <h4 style="padding-left:90px; color:#FFAA00;">Service 2</h4>
        
                <p style="float:right;padding-top:0px; margin-top: -81px;" >
    <Strong>Preparation Time:</Strong>3 hrs <br><Strong>Delivery time:</Strong> 30 min – 1.5 hrs</p>
                
             
             
        <hr >
        <h5 style="font-weight:700; font-family:arial;">Description</h5>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ornare leo non mollis id cursus. Eu euismod faucibus in leo malesuada. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ornare leo non mollis id cursus. Eu euismod faucibus in leo malesuada. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ornare leo non mollis id cursus. Eu euismod faucibus in leo malesuada.</p>
        codedata

        <?php
        // echo "<script>document.writeln(document.getElementsByTagName('code')[0]);
        // var t=document.getElementsByName('code')[0].innerHTML;');
        // document.writeln(t);        </script>";   
          ?>

<!-- <input  id="code" /> -->


       <section class="elementor-section elementor-top-section elementor-element elementor-element-b7fb50b elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="b7fb50b" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-9f60f4d" data-id="9f60f4d" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-ac85422 elementor-arrows-yes elementor-pagination-type-bullets elementor-review--has-separator elementor--star-style-star_fontawesome elementor-widget elementor-widget-reviews" data-id="ac85422" data-element_type="widget" data-settings="{&quot;slides_per_view&quot;:&quot;3&quot;,&quot;show_arrows&quot;:&quot;yes&quot;,&quot;pagination&quot;:&quot;bullets&quot;,&quot;speed&quot;:500,&quot;autoplay&quot;:&quot;yes&quot;,&quot;autoplay_speed&quot;:5000,&quot;loop&quot;:&quot;yes&quot;,&quot;pause_on_hover&quot;:&quot;yes&quot;,&quot;pause_on_interaction&quot;:&quot;yes&quot;,&quot;space_between&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:10,&quot;sizes&quot;:[]},&quot;space_between_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:10,&quot;sizes&quot;:[]},&quot;space_between_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:10,&quot;sizes&quot;:[]}}" data-widget_type="reviews.default">
				<div class="elementor-widget-container">
			<style>/*! elementor - v3.6.5 - 27-04-2022 */
.elementor-star-rating{color:#ccd6df;font-family:eicons;display:inline-block}.elementor-star-rating i{display:inline-block;position:relative;font-style:normal;cursor:default}.elementor-star-rating i:before{content:"\e934";display:block;font-size:inherit;font-family:inherit;position:absolute;overflow:hidden;color:#f0ad4e;top:0;left:0}.elementor-star-rating .elementor-star-empty:before{content:none}.elementor-star-rating .elementor-star-1:before{width:10%}.elementor-star-rating .elementor-star-2:before{width:20%}.elementor-star-rating .elementor-star-3:before{width:30%}.elementor-star-rating .elementor-star-4:before{width:40%}.elementor-star-rating .elementor-star-5:before{width:50%}.elementor-star-rating .elementor-star-6:before{width:60%}.elementor-star-rating .elementor-star-7:before{width:70%}.elementor-star-rating .elementor-star-8:before{width:80%}.elementor-star-rating .elementor-star-9:before{width:90%}.elementor-star-rating__wrapper{display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-align:center;-ms-flex-align:center;align-items:center}.elementor-star-rating__title{margin-right:10px}.elementor-star-rating--align-right .elementor-star-rating__wrapper{text-align:right;-webkit-box-pack:end;-ms-flex-pack:end;justify-content:flex-end}.elementor-star-rating--align-left .elementor-star-rating__wrapper{text-align:left;-webkit-box-pack:start;-ms-flex-pack:start;justify-content:flex-start}.elementor-star-rating--align-center .elementor-star-rating__wrapper{text-align:center;-webkit-box-pack:center;-ms-flex-pack:center;justify-content:center}.elementor-star-rating--align-justify .elementor-star-rating__title{margin-right:auto}@media (max-width:1024px){.elementor-star-rating-tablet--align-right .elementor-star-rating__wrapper{text-align:right;-webkit-box-pack:end;-ms-flex-pack:end;justify-content:flex-end}.elementor-star-rating-tablet--align-left .elementor-star-rating__wrapper{text-align:left;-webkit-box-pack:start;-ms-flex-pack:start;justify-content:flex-start}.elementor-star-rating-tablet--align-center .elementor-star-rating__wrapper{text-align:center;-webkit-box-pack:center;-ms-flex-pack:center;justify-content:center}.elementor-star-rating-tablet--align-justify .elementor-star-rating__title{margin-right:auto}}@media (max-width:767px){.elementor-star-rating-mobile--align-right .elementor-star-rating__wrapper{text-align:right;-webkit-box-pack:end;-ms-flex-pack:end;justify-content:flex-end}.elementor-star-rating-mobile--align-left .elementor-star-rating__wrapper{text-align:left;-webkit-box-pack:start;-ms-flex-pack:start;justify-content:flex-start}.elementor-star-rating-mobile--align-center .elementor-star-rating__wrapper{text-align:center;-webkit-box-pack:center;-ms-flex-pack:center;justify-content:center}.elementor-star-rating-mobile--align-justify .elementor-star-rating__title{margin-right:auto}}.last-star{letter-spacing:0}.elementor--star-style-star_unicode .elementor-star-rating{font-family:Arial,Helvetica,sans-serif}.elementor--star-style-star_unicode .elementor-star-rating i:not(.elementor-star-empty):before{content:"\002605"}</style><link rel="stylesheet" href="https://cheflick.code7labs.com/wp-content/plugins/elementor-pro/assets/css/widget-carousel.min.css">		<div class="elementor-swiper">
			<div class="elementor-main-swiper swiper-container">
				<div class="swiper-wrapper">
											
        


        <?php 
  // print_r($data);
for ($x = 0; $x < count($data); $x++) {


        ?>
        
        <div class="swiper-slide">
									<div class="elementor-testimonial elementor-repeater-item-bdb9647">
							<div class="elementor-testimonial__header">
											<div class="elementor-testimonial__image">
							<img src="https://cheflick.code7labs.com/wp-content/plugins/elementor/assets/images/placeholder.png" alt="John Doe">
						</div>
										<cite class="elementor-testimonial__cite"><span class="elementor-testimonial__name"><?php echo $data[$x]->username?> </span>
                    <div class="elementor-star-rating">
                      <?php 
                      $a =$data[$x]->rating ;
                      for ($yy = 0; $yy < $a ; $yy++){
                      ?>

                      <i class="elementor-star-full">&#xE934;</i>
                      <?php } ?>
                   
                      <?php 
                         $b  = 5 - $a ;
                      for ($yyy = 0; $yyy < $b ; $yyy++){
                      ?>

                      <i class="elementor-star-empty">&#xE934;</i>
                      <?php } ?>
                     
                    </div><span class="elementor-testimonial__title"><?php echo $data[$x]->rating_date ?> 	</span></cite>					<div class="elementor-testimonial__icon elementor-icon elementor-icon-twitter">
                      <i aria-hidden="true" class="fab fa-twitter"></i><span class="elementor-screen-only">Read More</span></div>				</div>
										<div class="elementor-testimonial__content">
					<div class="elementor-testimonial__text">
          <?php echo $data[$x]->feedback?> 					</div>
				</div>
					</div>
								</div>



                <?php 

              }

          ?>






    </div>
  </div>
</section>

  </div>
