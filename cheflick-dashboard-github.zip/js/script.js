$('#profileDrop').click(function(){
  $('#dropMenuCart').removeClass('show');
});
$('#dropMenu').click(function(){
  $('#profileDropdown').removeClass('show');
});