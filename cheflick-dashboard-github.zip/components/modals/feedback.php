<div class="modal fade" id="feedbackModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-body">
          <div class="row py-2 px-2">
                    <div class="col-sm-12">
                        <p class="bold voucherHead">Rate Kitchen</p>
                    </div>
                    <div class="col-sm-12">
                      <i class="fas fa-star starYellow"></i>
                      <i class="fas fa-star starYellow"></i>
                      <i class="fas fa-star starYellow"></i>
                      <i class="far fa-star starNorm"></i>
                      <i class="far fa-star starNorm"></i>
                    </div>
            </div>
            <div class="row py-2 px-2">
                    <div class="col-sm-12">
                        <p class="bold voucherHead">Add Feedback</p>
                    </div>
            </div>
            <div class="row mb-2 mt-2">
        <div class="col-lg-12">
          <div class="col-md-12 input-group input-group-lg voucherInput">
                <input type="text" class="form-control" placeholder="K-909, block 6, PECHS" />
            </div>
        </div>
    </div>
          <div class="row py-2 px-2">
                    <div class="col-sm-12">
                        <p class="bold voucherHead">Rate Dish</p>
                    </div>
                    <div class="col-sm-12">
                      <i class="fas fa-star starYellow"></i>
                      <i class="fas fa-star starYellow"></i>
                      <i class="fas fa-star starYellow"></i>
                      <i class="far fa-star starNorm"></i>
                      <i class="far fa-star starNorm"></i>
                    </div>
            </div>
            <div class="row py-2 px-2">
                    <div class="col-sm-12">
                        <p class="bold voucherHead">Add Feedback</p>
                    </div>
            </div>
            <div class="row mb-2 mt-2">
        <div class="col-lg-12">
          <div class="col-md-12 input-group input-group-lg voucherInput">
                <input type="text" class="form-control" placeholder="K-909, block 6, PECHS" />
            </div>
        </div>
    </div>
          </div>
      </div>
    </div>
  </div>
</div>